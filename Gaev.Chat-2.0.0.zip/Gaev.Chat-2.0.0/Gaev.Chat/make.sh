#!/bin/bash
dotnet publish --runtime ubuntu.16.04-x64 --configuration Release